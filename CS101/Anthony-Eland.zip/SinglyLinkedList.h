#ifndef SinglyLinkedList_T
#define SinglyLinkedList_T

#include <iostream>
using namespace std;

template <class T>
class Node
{
public:
	T data;
	Node* next;

	Node(T d, Node* n = NULL)
	{
		next = n;
		data = d;
	}
};

template <class T>
class SinglyLinkedList
{
private:
	Node<T> * head;
public:
	int length;
	SinglyLinkedList()
	{
		head = NULL;
		length = 0;
	}
	~SinglyLinkedList()
	{
		Node<T> * current = head;
		Node<T> * tp = current;
		while (current->next != NULL)
		{
			tp = current;
			current = current->next;
			tp->next = NULL;
			delete tp;
			tp = NULL;
		}
		delete current;
		head = current = tp = NULL;
	}
	Node<T>* GetStart()
	{
		return head;
	}
	T* ToArray()
	{
		T * arr = new T[length]();

		int i = 0;
		for (Node<T>* current = head; current != NULL; current=current->next)
		{
			arr[i] = current->data;
			i++;
		}
		arr[length] = '\0';
		return arr;
	}
	bool IsEmpty()
	{
		return (head == NULL) ? true : false;
	}
	void Add_To_Head(T d)
	{
		if (IsEmpty())
		{
			head = new Node<T>(d);
		}
		else
		{
			Node<T> * current = new Node<T>(d);
			current->next = head;
			head = current;
		}
		length++;
	}
	void Add_To_Tail(T d)
	{
		if (IsEmpty())
		{
			head = new Node<T>(d);
		}
		else
		{
			Node<T> * current = head;
			while (current->next != NULL)
			{
				current = current->next;
			}
			current->next = new Node<T>(d);
		}
		length++;
	}
	void Delete_From_Head()
	{
		if (IsEmpty())
		{
			return;
		}
		else
		{
			Node<T> * current = head;
			head = head->next;
			current->next = NULL;
			delete current;
			current = NULL;
		}
	}
	void Delete_From_Tail()
	{
		if (IsEmpty())
		{
			return;
		}
		else
		{
			Node<T> * current = head;
			while (current->next->next != NULL)
			{
				current = current->next;
			}
			Node<T> * curr = current->next;
			current->next = NULL;
			delete curr;
			curr = NULL;
		}
	}
	void Delete_Node_By_Value(T d)
	{
		if (IsEmpty())
		{
			return;
		}
		else
		{
			if (head->data == d)
			{
				Delete_From_Head();
			}
			else
			{
				Node<T> * current = head;
				Node<T> * tp = current;
				while (current != NULL)
				{
					if (current->data == d)
					{
						break;
					}
					tp = current;
					current = current->next;
				}
				if (current == NULL)
				{
					return;
				}
				else
				{
					tp->next = current->next;
					current->next = NULL;
					delete current;
					current = NULL;
				}
			}
		}
	}
	bool Search(T d)
	{
		if (IsEmpty())
		{
			return false;
		}
		else
		{
			Node<T> * current = head;
			while (current != NULL)
			{
				if (current->data == d)
				{
					break;
				}
				current = current->next;
			}
			if (current == NULL)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
	void Display()
	{
		for (Node<T> * current = head; current != NULL; current = current->next)
		{
			cout << current->data << " ";
		}
		cout << endl;
	}
};

#endif SinglyLinkedList_T