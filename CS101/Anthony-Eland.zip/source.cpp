#include <iostream>
#include <fstream>
#include <string>
#include "HuffmanCodeTree.h"
#include "SinglyLinkedList.h"
using namespace std;

int main(int argc, char *argv[])
{
	string x = argv[1];
	string x1 = argv[2];

	if (x == "encode")
	{
		char* arr;
		SinglyLinkedList<char> charlist;

		unsigned char ch;
		ifstream in(x1, ios::in | ios::binary | ios::ate);
		size_t size = 0; // here
		size = in.tellg(); // get the length of the file
		arr = new char[size];
		//cout << "Size of file: " << size << endl;
		in.seekg(0, ios::beg); // set the pointer to the beginning
		for (int i = 0; i<size; i++) {
			ch = in.get();
			arr[i] = ch;
			if (!charlist.Search(ch))
			{
				charlist.Add_To_Tail(ch);
			}
			//cout << (int)ch << endl;
		}

		int* intarr = new int[charlist.length]();

		int j = 0;

		for (Node<char>* ptr = charlist.GetStart(); ptr != NULL; ptr = ptr->next)
		{
			intarr[j] = 0;
			for (int i = 0; i < size; i++)
			{
				if (arr[i] == ptr->data)
				{
					intarr[j]++;
				}
			}
			j++;
		}

		char * listarr = charlist.ToArray();

		if (charlist.length >= 4)
		{
			char z = listarr[charlist.length - 4];
			int v = intarr[charlist.length - 4];
			listarr[charlist.length - 4] = listarr[charlist.length - 1];
			intarr[charlist.length - 4] = intarr[charlist.length - 1];
			listarr[charlist.length - 1] = z;
			intarr[charlist.length - 1] = v;

			z = listarr[charlist.length - 3];
			v = intarr[charlist.length - 3];
			listarr[charlist.length - 3] = listarr[charlist.length - 4];
			intarr[charlist.length - 3] = intarr[charlist.length - 4];
			listarr[charlist.length - 4] = z;
			intarr[charlist.length - 4] = v;
		}

		MinHeap obj(size, charlist.length);

		for (int i = 0; i < charlist.length; i++)
		{
			MinHeapNode * t = new MinHeapNode(listarr[i], intarr[i]);
			obj.Insert(t);
		}

		obj.BuildHuffmanTree();

		obj.GenerateCode();

		cout << "preorder contains the bytes (note that these are the VALUES of the bytes in the file, to see this output, run read on your file) :" << endl;
		obj.PreOrder();
		cout << endl << endl;
		cout << "inorder contains the bytes(see note above): " << endl;
		obj.InOrder();
		cout << endl << endl;
		cout << "codes.txt contains: " << endl;
		obj.CodeToFile(arr);
		cout << endl << endl;
	}

	system("Pause");
	return 0;
}