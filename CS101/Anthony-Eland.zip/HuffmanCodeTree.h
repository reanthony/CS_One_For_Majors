#ifndef HuffmanCodeTree_T
#define HuffmanCodeTree_T

#include <iostream>
#include <fstream>
#include "SinglyLinkedList.h"
using namespace std;

class TableNode
{
public:
	unsigned char alphabet;
	string encoded;

	void DisplayTableNode()
	{
		cout << alphabet << ": " << encoded << endl;
	}
};

class MinHeapNode
{
public:
	unsigned char data;
	int frequency;
	MinHeapNode *left, *right;

	MinHeapNode()
	{
		data = '~';
		frequency = 0;
		left = right = NULL;
	}
	MinHeapNode(char d, int f)
	{
		data = d;
		frequency = f;
		left = right = NULL;
	}
};

class MinHeap
{
private:
	int size;
	int capacity;
	MinHeapNode** arr;
	int internalcode;
	fstream write;
	int leafnodes;
	TableNode* table;
	int index; 
	bool first;

	void RestoreDownMin(int i)
	{

		int smallest = i;
		int left = 2 * i;
		int right = left + 1;

		if (left <= size && arr[left]->frequency < arr[smallest]->frequency)
		{
			smallest = left;
		}

		if (right <= size && arr[right]->frequency < arr[smallest]->frequency)
		{
			smallest = right;
		}

		if (smallest != i)
		{
			MinHeapNode* temp = arr[smallest];
			arr[smallest] = arr[i];
			arr[i] = temp;

			RestoreDownMin(smallest);
		}
	}
	void RestoreDownMax(int i)
	{

		int largest = i;
		int left = 2 * i;
		int right = left + 1;

		if (left <= size && arr[left]->frequency > arr[largest]->frequency)
		{
			largest = left;
		}

		if (right <= size && arr[right]->frequency > arr[largest]->frequency)
		{
			largest = right;
		}

		if (largest != i)
		{
			MinHeapNode* temp = arr[largest];
			arr[largest] = arr[i];
			arr[i] = temp;

			RestoreDownMax(largest);
		}
	}
	void RestoreUpMin(int i, MinHeapNode* temp)
	{
		int iparent = i / 2;

		while (iparent >= 1 && arr[iparent]->frequency > temp->frequency)
		{
			arr[i] = arr[iparent];
			i = iparent;
			iparent = i / 2;
		}
		arr[i] = temp;
	}
	void RestoreUpMax(int i, MinHeapNode* temp)
	{
		int iparent = i / 2;

		while (iparent >= 1 && arr[iparent]->frequency < temp->frequency)
		{
			arr[i] = arr[iparent];
			i = iparent;
			iparent = i / 2;
		}
		arr[i] = temp;
	}
	void GenerateCode_Private(MinHeapNode* root, int codes[], int top)
	{
		if (root->left != NULL)
		{
			codes[top] = 0;
			GenerateCode_Private(root->left, codes, top + 1);
		}
		if (root->right != NULL)
		{
			codes[top] = 1;
			GenerateCode_Private(root->right, codes, top + 1);
		}

		if (root->left == NULL && root->right == NULL)
		{
			SinglyLinkedList<char> obj;
			//cout << root->data << ": ";
			table[index].alphabet = root->data;
			for (int i = 0; i < top; i++)
			{
				unsigned char x = ' ';
				if (codes[i] == 0)
				{
					x = '0';
				}
				else
				{
					x = '1';
				}
				obj.Add_To_Tail(x);
			}
			table[index].encoded = obj.ToArray();
			//cout << table[index].encoded << endl;
			index++;
			//cout << endl;
		}
	}
	void PreOrder_Private(MinHeapNode* root)
	{
		cout.fill('0');
		cout.width(3);
		cout << (int)root->data << " ";
		write.put(root->data);
		if (root->left != NULL)
		{
			PreOrder_Private(root->left);
		}
		if (root->right != NULL)
		{
			PreOrder_Private(root->right);
		}
	}
	void InOrder_Private(MinHeapNode* root)
	{
		if (root->left != NULL)
		{
			InOrder_Private(root->left);
		}
		cout.fill('0');
		cout.width(3);
		cout << (int)root->data << " ";
		write.put(root->data);
		if (root->right != NULL)
		{
			InOrder_Private(root->right);
		}
	}
	string ToBinary(int n)
	{
		std::string r;
		while (n != 0) { r = (n % 2 == 0 ? "0" : "1") + r; n /= 2; }
		string x;
		int len = 16 - r.length();
		for (int i = 0; i < len; i++)
		{
			x = x + "0";
		}
		x = x + r;
		return x;
	}
	int CalculateZero(int x,int sum)
	{
		while (x <= sum)
		{
			x += 8;
		}
		if (x == sum)
		{
			return 0;
		}
		else
		{
			return (x - sum);
		}
	}
public:
	MinHeap()
	{
		size = capacity = 0;
		arr = NULL;
		internalcode = 128;
		leafnodes = 0;
		table = NULL;
	}
	MinHeap(int cap, int nodes)
	{
		size = 0;
		capacity = cap + 1;
		arr = new MinHeapNode*[capacity];
		for (int i = 0; i < capacity; i++)
		{
			arr[i] = new MinHeapNode();
		}
		leafnodes = nodes;
		internalcode = 132;
		table = new TableNode[nodes];
		first = true;
	}
	MinHeapNode* ExtractMin()
	{
		MinHeapNode* temp = arr[1];
		arr[1] = arr[size];

		size--;
		RestoreDownMin(1);

		return temp;
	}
	MinHeapNode* ExtractMax()
	{
		MinHeapNode* temp = arr[1];
		arr[1] = arr[size];

		size--;
		RestoreDownMax(1);

		return temp;
	}
	void Insert(MinHeapNode* temp)
	{
		size++;
		arr[size] = temp;
		if (first)
		{
			RestoreUpMax(size, temp);
		}
		else
		{
			RestoreUpMin(size, temp);
		}
	}
	void DisplayMinHeap()
	{
		for (int i = 1; i <= size; i++)
		{
			cout << arr[i]->data << " " << endl;
		}
		cout << endl;
	}
	void BuildHuffmanTree()
	{
		MinHeapNode *left, *right, *top;

		int temp = size;

		int c = 0;

		if (size % 2 != 0)
		{
			while (temp > 1)
			{
				temp -= 2;
				c++;
			}
		}
		else
		{
			while (temp > 0)
			{
				temp -= 2;
				c++;
			}
		}

		MinHeapNode * t = new MinHeapNode[c];

		first = true;

		int ind = 0;

		if (temp % 2 != 0)
		{
			while (size != 1)
			{
				if (first)
				{
					right = ExtractMax();
					left = ExtractMax();
				}
				else
				{
					right = ExtractMin();
					left = ExtractMin();
				}

				top = new MinHeapNode(char(internalcode), left->frequency + right->frequency);

				top->left = left;
				top->right = right;

				internalcode -= 2;

				t[ind] = *top;
				ind++;
			}
		}
		else
		{
			while (size != 0)
			{
				if (first)
				{
					right = ExtractMax();
					left = ExtractMax();
				}
				else
				{
					right = ExtractMin();
					left = ExtractMin();
				}

				top = new MinHeapNode(char(internalcode), left->frequency + right->frequency);

				top->left = left;
				top->right = right;

				internalcode -= 2;

				t[ind] = *top;
				ind++;
			}
		}

		internalcode = 129;

		first = false;

		for (int i = 0; i < c; i++)
		{
			Insert(&t[i]);
		}

		while (size != 1)
		{
			if (first)
			{
				right = ExtractMax();
				left = ExtractMax();
			}
			else
			{
				right = ExtractMin();
				left = ExtractMin();
			}

			top = new MinHeapNode(char(internalcode), left->frequency + right->frequency);

			top->left = left;
			top->right = right;

			internalcode+=2;

			Insert(top);
		}

	}
	void GenerateCode()
	{
		int codes[100]; int top = 0;

		GenerateCode_Private(arr[1], codes, top);
	}
	void PreOrder()
	{
		if (arr[1] != NULL)
		{
			write.open("Preorder.txt", ios::out);
			PreOrder_Private(arr[1]);
			write.close();
		}
	}
	void InOrder()
	{
		if (arr[1] != NULL)
		{
			write.open("Inorder.txt", ios::out);
			InOrder_Private(arr[1]);
			write.close();
		}
	}
	void DisplayCodes()
	{
		for (int i = 0; i < index; i++)
		{
			table[i].DisplayTableNode();
		}
	}
	void CodeToFile(string s)
	{	
		fstream write1("code.bin",ios::out | ios::binary | ios::in);
		string n = ToBinary(index);
		write.open("code.txt", ios::out);
		for (int i = 0; i < s.length(); i++)
		{
			for (int j = 0; j < index; j++)
			{
				if (s[i] == table[j].alphabet)
				{
					cout << table[j].encoded;
					write << table[j].encoded;
					n += table[j].encoded;
				}
			}
		}
		int sum = n.length();
		int z = CalculateZero(0, sum);
		for (int i = 0; i < z; i++)
		{
			n += "0";
		}
		write1 << n;
	}
};

#endif HuffmanCodeTree_T