/* Eland Anthony- Project 2
Project of several function dealing with char and int data of a doubly linked list*/

#include<stdlib.h>
#include<string.h>
struct node {
char type;
int key;
struct node *next, *prev;
};
class dList {
    private:
    public:
    struct node *head = NULL;
    dList()
    {
        head=NULL;
    }
    dList(int arraykey[], char arraytype[],int size)
    {
        for(int i=size-1;i>=0;i--)
        {
            struct node *newNode=(struct node *)malloc(sizeof(struct node));
            newNode->key=arraykey[i];
            newNode->type=arraytype[i];
            newNode->next=head;
            newNode->prev=NULL;
            if(head!=NULL) {
                head->prev=newNode;
            }
            head=newNode;
        }
    }
    void addFront(int keytwo, char type_)
    {
        struct node *newNode=(struct node *)malloc(sizeof(struct node));
        newNode->key=keytwo;
        newNode->type=type_;
        newNode->next=head;
        newNode->prev=NULL;
        if(head!=NULL) {
            head->prev=newNode;
        }
        head=newNode;
    }
    void addBack(int keytwo, char type_)
    {
        struct node *listed;
        listed=head;
        while(listed->next!=NULL) {
            listed=listed->next;
        }
        struct node *newNode=(struct node *)malloc(sizeof(struct node));
        newNode->key=keytwo;
        newNode->type=type_;
        listed->next=newNode;
        newNode->next=NULL;
        newNode->prev=listed;
    }
    node* search(int keytwo)
    {
        struct node *listed;
        listed=head;
        while(listed!=NULL)
        {
            if(listed->key==keytwo)
            {
                return listed;
            }
            listed=listed->next;
        }
        return NULL;
    }
    void find(char type_)
    {
        struct node *listed;
        int indicator=0;
	listed=head;
        while(listed!=NULL)
        {
            if(toupper(listed->type)==toupper(type_))
            {
                indicator=1;
                cout<<listed->key<<" "<<type_ << "\t";
            }
            listed=listed->next;
        }
	cout << endl;
        if(!indicator)
        {
            cout<<"\nError: There is no key for type: "<<type_<<"in this list\n";
        }
    }
    void moveFront(struct node *shift)
    {
        struct node *listed;
        listed=head;
        int indicator=0;
        if(head->prev==NULL&&head->next==NULL)
        {
        cout<<"\nError: Only one node is in the list.\n";
  }
        while(listed!=NULL&&shift!=NULL)
        {
            if(shift->key==listed->key)
            {
                indicator=1;
                break;
            }
            listed=listed->next;
        }
        if(indicator)
        {
            if(listed==head)
            {
                cout<<"\nError: This node is already at the front of the list\n";
            }
            else if(listed->next==NULL)
            {
                listed->prev->next=NULL;
                listed->prev=NULL;
                head->prev=listed;
                listed->next=head;
                head=listed;
            }
            else
            {
                listed->prev->next=listed->next;
                listed->next->prev=listed->prev;
                listed->prev=NULL;
                head->prev=listed;
                listed->next=head;
                head=listed;
           }
 }
        else
        {
            cout<<"\nError: Incomplete address\n";
        }
    }
  
    void moveBack(struct node *shift)
    {
    if(head->prev==NULL&&head->next==NULL)
        {
        cout<<"\nError: Only one node is in the list.\n";
  }
  if(head==NULL)
  {
   cout<<"\n\tError: There is no list"<<"\n";
  }
        struct node *listed;
        listed=head;
        int indicator=0;
        struct node *end;
	end=head;
        while(end->next!=NULL)
        {
            end=end->next;
        }
        while(listed!=NULL&&shift!=NULL)
        {
            if(shift->key==listed->key)
            {
                indicator=1;
                break;
            }
            listed=listed->next;
        }
        if(indicator)
        {
            if(listed->next==NULL)
            {
                cout<<"\nError: This node is already at the End of the list\n";
            }
            else if(listed==head)
            {
                head=head->next;
       head->prev=NULL;
       listed->prev=end;
       listed->next=NULL;
       end->next=listed;
            }
            else
            {
                listed->prev->next=listed->next;
                listed->next->prev=listed->prev;
                listed->prev=end;
                listed->next=NULL;
                end->next=listed;
            }
        }
        else
        {
            cout<<"\n Error: This address is not belongs to the list.\n";
        }
    }
    void out(int k, char letterf= 'f')
    {
        int indicator=0;
        int count=0;
        struct node *listed;
        if(tolower(letterf)=='f')
        {
            struct node *end=head;
            while(end->next!=NULL)
            {
                end=end->next;
            }
            listed=end;
            while(listed!=head&&count<k)
            {
		   cout<<listed->key<< " " << listed->type<<"\t";
                   count++;
                   indicator=1;
                   listed=listed->prev;
            }
            if(!indicator)
            {
                cout<<"Error: There are no elements within this list.\n";
            }
        }
        else if(tolower(letterf)=='b')
        {
            listed=head;
            while(listed!=NULL&&count<k)
            {
     cout<<listed->key<< " " << listed->type<<"\t";
                   count++;
                   indicator=1;
                   listed=listed->next;
            }
            if(!indicator)
            {
                cout<<"Error: There are no elements in the list.\n";
            }
        }
        else
        {
            cout<<"\nError: Invalid indicated start.\n";
        }
        cout<<endl;
    }
   void sort()
    {
       node *head= mergeSort( head);
    }
    struct node *split(struct node *head) {
    struct node *fast = head,*slow = head;
    while (fast->prev && fast->prev->prev)
    {
        fast = fast->prev->prev;
        slow = slow->prev;
    }
    struct node *temp = slow->prev;
    slow->prev = NULL;
    return temp;
}
struct node *merge(struct node *first, struct node *second)
{
    if (!first)
        return second;
    if (!second)
        return first;
    if (first->key < second->key) {
        first->prev = merge(first->prev,second);
        first->prev->next = first;
        first->next = NULL;
        return first;
    }
    else
    {
        second->prev = merge(first,second->prev);
        second->prev->next = second;
        second->next = NULL;
        return second;
    }
}
 
struct node *mergeSort(struct node *head)
{
    if (!head || !head->prev)
        return head;
    struct node *second = split(head);
    head = mergeSort(head);
    second = mergeSort(second);
    return merge(head,second);
}
};
