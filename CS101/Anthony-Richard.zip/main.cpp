/*Richard Eland Anthony - 
Program to use start vertex, end vertex, and maximum cost to output the tital duration of a flight utilizing the Bellman-Ford algorithm*/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <list>
using namespace std;

class Edge
{
  public:
    Edge(int startV, int endV, int cost, int duration)
    {
        this->startV = startV;
        this->endV = endV;
        this->cost = cost;
        this->duration = duration;
    }
    Edge()
    {
        this->startV = 0;
        this->endV = 0;
        this->cost = 0;
        this->duration = 0;
    }

    void setStart(int startV)
    {
        this->startV = startV;
    }
    void setEnd(int endV)
    {
        this->endV = endV;
    }
    void setCost(int cost)
    {
        this->cost = cost;
    }
    void setDuration(int duration)
    {
        this->duration = duration;
    }

    int getStart()
    {
        return startV;
    }
    int getEnd()
    {
        return endV;
    }
    int getCost()
    {
        return cost;
    }
    int getDuration()
    {
        return duration;
    }
    void Print()
    {
        cout << endl
             << startV << "-" << endV << "-" << cost << "-" << duration << endl;
    }

  private:
    int startV;
    int endV;
    int cost;
    int duration;
};
struct Graph
{
    int numberOfNodes;
    int numberofVertices;
    // to store the nodes
    Edge *database;
    list<int> *adj;

    void addEdge(int start, int end)
    {
        adj[start].push_back(end);
    }

    int getEdgeDurationMinimum(int start, int end)
    {
        int duration = 0;
        int min = 9999;
        for (int i = 0; i < numberofVertices; i++)
        {
            if ((database[i].getStart() == start) && (database[i].getEnd() == end) && (database[i].getCost() < min))
            {
                duration = database[i].getDuration();
                min = database[i].getCost();
            }
        }
        return duration;
    }
    int getEdgeCostMinimum(int start, int end)
    {
        int min = 9999;
        for (int i = 0; i < numberofVertices; i++)
        {
            if ((database[i].getStart() == start) && (database[i].getEnd() == end) && (database[i].getCost() < min))
            {
                min = database[i].getCost();
            }
        }
        return min;
    }
} graph;

struct DurationList
{
    int cost[20];
    int duration[20];
    int paths;
    DurationList()
    {
        paths = 0;
    }
    void addPath(int costS, int durationS)
    {
        cost[paths] = costS;
        duration[paths] = durationS;
        paths++;
    }
    int getDurationinCostLimit(int costLimit)
    {
        int dur=0;
        for (int i = 0; i < paths; i++)
        {
            if (cost[i] <= costLimit)
            {
                dur=duration[i];
            }
        }
        return dur;
    }
} durationPaths;
int readFile(char *filename)
{
    FILE *fp;
    char buffer[255];
    //opening file
    fp = fopen(filename, "r");
    // if error reading file
    if (fp == NULL)
    {
        printf("Error reading file\n");
        return 0;
    }
    // to detect the first line
    int lineCount = 0;
    int firstLineSplit = 0;
    int otherSplitCount = 0;
    int start = 0;
    int end = 0;
    int cost = 0;
    int duration = 0;
    //reading till end
    while (fgets(buffer, 255, (FILE *)fp))
    {
        // spitting on the basis of the space
        char *token = strtok(buffer, " ");
        while (token != NULL)
        {
            int numInt;
            sscanf(token, "%d", &numInt);
            //When the line is the first
            if (lineCount == 0)
            {
                //total number of nodes
                if (firstLineSplit == 0)
                {
                    graph.numberOfNodes = numInt;
                }
                //total number of vertices
                if (firstLineSplit == 1)
                {
                    //alocating memory
                    graph.numberofVertices = numInt;
                    graph.database = new Edge[numInt];
                    graph.adj = new list<int>[graph.numberofVertices];
                    // cout << "Memory allocated";
                }
            }
            else
            {
                if (otherSplitCount == 0)
                {
                    start = numInt;
                }
                else if (otherSplitCount == 1)
                {
                    end = numInt;
                }
                else if (otherSplitCount == 2)
                {
                    cost = numInt;
                }
                else if (otherSplitCount == 3)
                {
                    duration = numInt;
                    otherSplitCount = -1;
                    //Setting values
                    graph.database[lineCount - 1].setStart(start);
                    graph.database[lineCount - 1].setEnd(end);
                    graph.database[lineCount - 1].setCost(cost);
                    graph.database[lineCount - 1].setDuration(duration);

                    graph.addEdge(start, end);
                }
                otherSplitCount++;
            }
            // cout << token << "|";
            //splitting next one
            token = strtok(NULL, " ");
            firstLineSplit++;
        }
        lineCount++;
    }

    fclose(fp);
}

void BellmanFord(int src, int destination)
{
    const int vertices = graph.numberofVertices;
    const int edges = graph.numberOfNodes;
    int distance[vertices];

    for (int i = 0; i < vertices; i++)
    {
        distance[i] = 99999;
    }
    distance[src] = 0;
    for (int i = 1; i <= vertices - 1; i++)
    {
        for (int j = 0; j < edges; j++)
        {
            int u = graph.database[j].getStart();
            int v = graph.database[j].getEnd();
            int weight = graph.database[j].getCost();
            if (distance[u] != 99999 && distance[u] + weight < distance[v])
            {
                distance[v] = distance[u] + weight;
            }
        }
    }
}
void printAllPathsUtil(int u, int d, bool visited[],
                       int path[], int &pathIndex)
{

    // Mark the current node and store it in path[]
    visited[u] = true;
    path[pathIndex] = u;
    pathIndex++;

    // If current vertex is same as destination, then print
    // current path[]
    if (u == d)
    {
        int duration = 0;
        int cost = 0;
        for (int i = 0; i < pathIndex; i++)
        {
            if (i != pathIndex - 1)
            {
                duration = duration + graph.getEdgeDurationMinimum(path[i], path[i + 1]);
                cost = cost + graph.getEdgeCostMinimum(path[i], path[i + 1]);
                // cout << path[i] << " ( " << duration << "," << cost << " )"
                //      << " ";
            }
            else
            {
                // cout << path[i] << " ";
            }
        }
        durationPaths.addPath(cost, duration);
        // cout << endl;
    }
    // If current vertex is not destination
    else
    {
        list<int>::iterator i;
        for (i = graph.adj[u].begin(); i != graph.adj[u].end(); ++i)
            if (!visited[*i])
                printAllPathsUtil(*i, d, visited, path, pathIndex);
    }

    // Remove current vertex from path[] and mark it as unvisited
    pathIndex--;
    visited[u] = false;
}

void getAllPaths(int s, int d)
{
    const int vertices = graph.numberofVertices;
    const int edges = graph.numberOfNodes;
    // Mark all the vertices as not visited
    bool *visited = new bool[vertices];
    // Create an array to store paths
    int *path = new int[vertices];
    int pathIndex = 0; // Initialize path[] as empty
    // Initialize all vertices as not visited
    for (int i = 0; i < vertices; i++)
        visited[i] = false;
    // Call the recursive helper function to print all paths
    printAllPathsUtil(s, d, visited, path, pathIndex);
}

int main(int argc, char *argv[])
{
    if (argc < 5)
    {
        cout << "Please enter the correct command line arguments!\n";
        cout << "Program exiting\n";
        return 0;
    }
    readFile(argv[1]);
    int start;
    int end;
    int limit;
    sscanf(argv[2], "%d", &start);
    sscanf(argv[3], "%d", &end);
    sscanf(argv[4], "%d", &limit);

    BellmanFord(start, end);
    getAllPaths(start, end);

    cout << durationPaths.getDurationinCostLimit(limit) << endl;
}
