/* Richard Eland Anthony - Project 1
Project to count words and unique words, which additionally searches the value of repatition of occurence for input words*/
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <cctype>

//prevent repetative std inclusion
using namespace std;
//Function to search for # of occurences
void search(string foo[10000], int total, string inpStr) {
	string equals[total];
	int toMatch = 0;
	int totalOcrns = 0;
	bool flag = false;
	
	for(int x = 0; x < total; x++) {
		string currChar = foo[x];
		bool isMatch = false;
		//Dictate whether matching
		if(currChar.length() <= inpStr.length()) {
			for(int y = 0; y < (signed) inpStr.length(); y++) {
				if(inpStr[y] == currChar[y]) {
					isMatch = true;
				}
				else if(inpStr[y] == '?') {
					isMatch = true;
				}
				else {
					isMatch = false;
					break;
				}
					}
						}
		bool matched = false;
		for(int z = 0; z < toMatch; z++) {
			if(currChar.compare(equals[z]) == 0) {
				matched = true;
			}
				}
		//If correct match, add to total occurences
		if(!matched && inpStr.length() <= currChar.length()) {
			if(isMatch) {
				//Flag = true determines that there is at least one match
				flag = true;
				for(int z = 0; z < total; z++) {
					if(currChar.compare(foo[z]) == 0) {
						totalOcrns++;
					}
						}
				cout << "The word " << currChar << " appears " << totalOcrns << " times in the document" << endl;
			//Reset occurences
			totalOcrns = 0;
			}
		equals[toMatch++] = currChar;
		}
		}
		if (flag == false)  { 
			cout << "The word " << inpStr << " appears 0 times in the document" << endl;
			}
	return;
	}

//Function to check for unique words
int newTot(string foo[10000], int num) {
string newArr[num];
int count = 0;
bool checkUnique = true;
for(int x = 0; x < num; x++) {
	checkUnique = true;
	//Check if the scan is a repeated word
	for(int y = 0; y < num; y++) {
		if(foo[x].compare(newArr[y]) == 0) {
			checkUnique = false;
		}
	}
	if(checkUnique) {
		newArr[count++] = foo[x];
	}
}
return count;
}

//Function for tolower each char
string toLower(string currChar) {
int x;
for(x = 0; x < (signed) currChar.length(); x++) {
	currChar[x] = tolower(currChar[x]);
	}
return currChar;
}

//Main function
int main(int argc, char** argv) {
ifstream infile;
infile.open(argv[1]);
if(infile.fail()) {
	cout << "File does not exist" <<endl;
	return 0;
	}
string foo[10000];
string currChar;
int total = 0;
int newCntr = 0;
//Take in file
while(infile >> currChar) {
	bool isBreak = false;
	for(int z = 0; z < (signed) currChar.length(); z++) {
		if(isalpha(currChar[z])) {

		}	
		//else make lowercase
		else {
			foo[total++] = toLower(currChar.substr(0, z));
			isBreak = true;
				//If word ends
				if(currChar[z+1] != '\0') {
					string newStr;
					for(int q = z+1; q < (signed) currChar.length(); q++) {
						newStr += currChar[q];
						}
					foo[total++] = toLower(newStr);
					}
		}
	}
	if(!isBreak) {
		foo[total] = toLower(currChar);
		total++;
		}
}
//Find Unique words using newCtr function
newCntr = newTot(foo, total);
cout << "The number of words found in the file was " << total << endl;
cout << "The number of unique words found in the file was " << newCntr << endl;
string inpStr = "";
cout << "Please enter a word: ";
cin >> inpStr;
//While input != 'END', prompt for input
while(inpStr.compare("END") != 0) {
	search(foo, total, toLower(inpStr));
	cout << "Please enter a word: ";
	cin >> inpStr;
	}
//Close file and end program
infile.close();
return 0;
}
